import React from "react";
import { ScrollView, View, Image,Text } from "react-native";
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';


export default function Home1() {
  return (
    <View>
<View className="flex w-full bg-orange-400 h-full">
    <View className="flex bg-slate-800 mt-7 flex-row h-48">
    <Image 
    source={require('../Images/3.jpg')}
    className="w-64 h-48 rounded-lg"
    />
    </View>
    <View className="flex bg-gray-200 h-1/3 justify-center items-center">
        <Text className="text-xl font-bold">Menu</Text>
      </View>

      <View className="flex bg-gray-300 h-1/3 justify-center items-center">
        <Text className="text-xl font-bold">Deals</Text>
      </View>

</View>


    </View>
  );
}
